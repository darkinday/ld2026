<?php
$conn = mysqli_connect("192.168.1.77", "root", "G@GWFby@whNge36Yjr6.Pzf!78cPqM", "forum");

session_start();

if (isset($_SESSION['username'])) {
    session_destroy();
}
Header("Location:index.php");